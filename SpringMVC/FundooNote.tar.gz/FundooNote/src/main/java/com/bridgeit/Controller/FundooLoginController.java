package com.bridgeit.Controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bridgeit.JSON.Response;
import com.bridgeit.Model.Login;
import com.bridgeit.Model.Register;
import com.bridgeit.Services.UserService;

@Controller
public class FundooLoginController {
	@Autowired
	UserService service;
	
	Logger logger=Logger.getLogger(FundooLoginController.class);
	
	@RequestMapping(value="login",method=RequestMethod.POST ,consumes="application/json")
	public @ResponseBody ResponseEntity loginuser(@RequestBody Login user)
	{
		logger.info("Inside Login");
		Register reg=service.getUser(user);
		logger.info(reg);
		if(reg!=null)
		{
			return new ResponseEntity(HttpStatus.OK);
		}
		return new ResponseEntity(HttpStatus.BAD_REQUEST);
		 
	}
	
}
