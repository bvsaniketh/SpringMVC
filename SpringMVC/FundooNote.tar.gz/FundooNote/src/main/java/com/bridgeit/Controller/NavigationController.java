/*package com.bridgeit.Controller;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class NavigationController {

	@RequestMapping(value="Register", method=RequestMethod.GET)
	
	public void gotoreg()
	{
		
		ModelAndView mav=new ModelAndView("register");
		System.out.println("Gone to Registration");
	}
		
	@RequestMapping(value="Login", method=RequestMethod.GET)
	public void gotologin()
	{
		ModelAndView mav=new ModelAndView("login");
		System.out.println("Gone to Login");
				
	}
}
*/