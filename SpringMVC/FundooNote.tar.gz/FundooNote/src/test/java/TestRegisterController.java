import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.bridgeit.JSON.Response;
import com.bridgeit.Model.Register;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class TestRegisterController {

	static Register user1;
	static Register user2;
	Register user3;
	Register user4;
	Logger logger = Logger.getLogger(TestRegisterController.class);

	@BeforeClass
	public static void setup() {
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 8080;
		RestAssured.basePath = "/FundooNote";

		user1 = new Register();
		user1.setName("Aniketh");
		user1.setEmail("bvsaniketh95@gmail.com");
		user1.setAge(25);
		user1.setMobile(472342);
		user1.setUsername("subbu");
		user1.setPassword("subbu");

		user2 = new Register();
		user2.setName("Luis Suarez");
		user2.setEmail("robo@gmail.com");
		user2.setAge(25);
		user2.setMobile(472342);
		user2.setUsername("luis");
		user2.setPassword("suarez");

	}

	@Test
	public void testRegister() {
		// String jsonString =user1.toJSONString;
		System.out.println("testRegister");
		Response resp=(Response) given().contentType("application/json").body(user2).when().post("register").then().statusCode(200);
		System.out.println(resp);
	}

	/*
	 * @Test
	 * 
	 * @Ignore public void testInsertRegister() { logger.info("insert user");
	 * RestAssured.given().body(user2).contentType("application/json").when().post(
	 * "register").then().statusCode(200); }
	 */

}
