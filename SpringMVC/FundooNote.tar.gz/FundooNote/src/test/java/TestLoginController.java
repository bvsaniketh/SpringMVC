import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bridgeit.Model.Login;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;


public class TestLoginController {
	
	Logger logger=Logger.getLogger(TestLoginController.class);
	static Login user1;
	static Login user2;
	@BeforeClass
	public static void setup()
	{
		RestAssured.baseURI="http:localhost";
		RestAssured.port=8080;
		RestAssured.basePath="FundooNote";
		
		
		user1=new Login();
		user1.setUsername("bvsaniketh");
		user1.setPassword("bridgeit");
		
		user2=new Login();
		user2.setUsername("fjakf");
		user2.setPassword("fjafas");
		
	}
	
	@Test
	public void testLogin()
	{
		logger.info("Testing Login Controller");
		given().contentType(ContentType.JSON).body(user1).when().post("login").then().statusCode(400);
	}
}
